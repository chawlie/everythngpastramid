<?php
 /**
  * Title: Sidebar
  * Description: This is the default sidebar and displays widgets assigned to the "Sidebar - Page Left" widget area.
  * Documentation: http://codex.wordpress.org/Function_Reference/dynamic_sidebar
  */
?>
<?php dynamic_sidebar('sidebar-page-left'); ?>
