<?php
/**
 * Template Name: The Story
 */
get_header(); ?>
	<?php while (have_posts()): the_post(); ?>
		<?php get_template_part('parts/hero'); ?>
		<section class="section">
			<div class="row">
				<div class="columns small-12 medium-10 medium-push-1 text-center">
					<h2>It sounds cliché. And saying “it sounds cliché” sounds cliché. Nevertheless, here’s their story…</h2>
				</div>
				<div class="columns small-12 medium-8 medium-push-2">
					<p>Everything Pastrami’d was founded in 2018 by three college buddies who were shooting the proverbial sh*t over some adult beverages at a typical backyard Texas barbecue in Austin. While sipping drinks and staring at a smoker for what seemed like hours, the conversation somehow meandered to BBQ and a realization that to get really good craft barbecue you have to either do it yourself (which requires a lot of waiting) or go out to a local barbecue joint and empty your wallet.</p>
					<p>So later that night after the smoke cleared, Greg, Jason and Mike decided to listen to their alcohol-soaked hearts, ditch their college degrees, lay waste to their corporate careers, and follow their passion for barbecue. <strong>And Everything Pastrami’s was born.</strong></p>
				</div>
			</div>
		</section>
		<section class="section section-sm">
	        <div class="row">
	            <div class="columns small-12 large-10 large-push-1 flex">
	                <div class="columns small-12 medium-6">
	                    <img src="<?php bloginfo('template_url'); ?>/site/images/beefribs-withknife.jpg" class="margin-bottom-30" alt="">
	                </div>
	                <div class="columns small-12 medium-6">
	                    <h3>Their mission was simple:</h3>
	                    <p class="lead">Start and innovative smoked meats company that passionately procures meats with a unique and delicious twist. </p>
	                </div>
	            </div>
	        </div>
	    </section>
		<section class="section text-center">
			<div class="row">
				<div class="columns small-12 medium-8 medium-push-2 text-center">
					<h2>If the name didn’t give it away, the delicious twist is that they pastrami everything.</h2>
				</div>
				<div class="columns small-12 medium-8 medium-push-2">
					<p> It definitely takes more time and effort, but excellence can’t be rushed. These three guys are dedicated to bringing you amazing flavorful barbecue at a fair price.</p>
					<p>Thank you for supporting the little guys. Seriously, your support is very much appreciated!</p>
				</div>
			</div>
		</section>
	<?php endwhile; ?>
<?php get_footer(); ?>
