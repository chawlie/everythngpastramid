<?php
/**
 * Template Name: Our Meat
 */
get_header(); ?>
	<?php while (have_posts()): the_post(); ?>
		<?php get_template_part('parts/hero'); ?>
			<section class="section">
				<div class="row">
					<div class="columns small-12 medium-10 medium-push-1 text-center">
						<div class="columns small-12 medium-5">
							<h2>Why Try Us?</h2>
							<p>We believe our customers should get the most flavorful smoked meats that are a break from the norm, at a fair price.</p>
						</div>
						<div class="columns small-12 medium-5 medium-push-1">
							<h2>How do we do it?</h2>
							<p>It’s just a simple combination practice, patience and a taste for perfection.</p>
						</div>
					</div>
				</div>
			</section>
			<section>
				<div class="row">
					<div class="columns small-12 medium-10 medium-push-1 text-center">
						<h2>Our Brine and Time Process</h2>
					</div>
					<div class="columns small-12 medium-8 medium-push-2">
						<p>It’s more work but it is worth it. We start by brining all of our quality beef, pork and chicken. This helps us create a more flavorful and tender product. From there we add more flavor by coating our products with a thick layer of rub (this is the kicker) and smoke them for up to 15 hours. It is a painstakingly process but the results are well worth it. And you deserve it!</p>
					</div>
				</div>
			</section>
			<section class="section">
		        <div class="row text-center">
		            <div class="columns small-12 medium-8 medium-push-2">
		                <img src="<?php bloginfo('template_url'); ?>/site/images/meats-slider.jpg" alt="">
		            </div>
		        </div>
		    </section>
			<section class="section">
				<div class="row">
					<div class="columns small-12 medium-10 medium-push-1 text-center">
						<h2>We Don’t Hide Behind Sauce</h2>
					</div>
					<div class="columns small-12 medium-8 medium-push-2">
						<p>The only way for a consumer to truly tell if the meat they’re buying is tender and full of flavorful is to sell it without sauce, which we do. In addition to hiding minor league meats in major league sauces, others will use sauce as a way to drive their profits by offering less meat, and, you guessed it, more sauce.  That doesn’t sit right with us. Ain’t nobody got time for that.</p>
						<p>Don’t get us wrong, we love getting sauced! But we don’t cut corners around here. Our flavor is undisputed, bite for bite. And to keep a winning record, it’s gotta come out sans sauce. What you do with it is up to you.</p>
					</div>
				</div>
			</section>
			<section class="section">
				<div class="row">
					<div class="columns small-12 medium-4">
						<div class="meat-type-container">
							<h3>Pastrami’d</h3>
							<div class="meat-type">
								<h4>Beef</h4>
							</div>
							<div class="meat-cuts">
								<ul>
									<li>Plate Short Ribs</li>
									<li>Chuck Short Ribs</li>
									<li>Brisket</li>
									<li>Tenderloin</li>
									<li>Beef Shank</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="columns small-12 medium-4">
						<div class="meat-type-container">
							<h3>Pastrami’d</h3>
							<div class="meat-type">
								<h4>Pork</h4>
							</div>
							<div class="meat-cuts">
								<ul>
									<li>Pork Ribs</li>
									<li>Pork Butt</li>
									<li>Cushion</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="columns small-12 medium-4">
						<div class="meat-type-container">
							<h3>Pastrami’d</h3>
							<div class="meat-type">
								<h4>Poultry</h4>
							</div>
							<div class="meat-cuts">
								<ul>
									<li>Chicken Wings</li>
									<li>Chick Drumettes</li>
									<li>Turkey Legs</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="section">
				<div class="row">
					<div class="columns small-12 medium-10 medium-push-1 text-center">
						<h2> If you are on the hunt for great barbecue that is uniquely delicious, please give us a try! </h2>
						<a href="contact-us/" class="btn">CONTACT US</a>
					</div>
				</div>
			</section>
	<?php endwhile; ?>
<?php get_footer(); ?>
