<?php
/**
 * Template Name: Home Page
 */
get_header(); ?>

<?php while (have_posts()): the_post(); ?>
    <?php get_template_part('parts/hero'); ?>
    <section class="section">
        <div class="row">
            <div class="columns small-12 medium-10 medium-push-1 text-center">
                <h2 class="blue-banner">Quality Meats • Fresh Ingredients</h2>
            </div>
        </div>
        <div class="row">
            <div class="columns small-12 large-10 large-push-1">
                <div class="columns small-12 medium-6">
                    <img src="<?php bloginfo('template_url'); ?>/site/images/beefribs.jpg" class="margin-bottom-30" alt="">
                </div>
                <div class="columns small-12 medium-6">
                    <h3>Slowly Cured and Carefully Crafted Over Time</h3>
                    <p>We start by brining all of our quality beef, pork and chicken. This helps us create a more flavorful and tender product. From there we add more flavor by coating our products with a thick layer of rub (this is the kicker) and smoke them for up to 15 hours. It is a painstakingly process but the results are well worth it. And you deserve it!</p>
                    <a href="our-meat/" class="btn">Read more about Our Process</a>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="row full-width home-images-container">
            <div class="columns small-12 medium-6">
                <img src="<?php bloginfo('template_url'); ?>/site/images/beefribs-split.jpg" alt="">
            </div>
            <div class="columns small-12 medium-6 butcher-knives">
                <img src="<?php bloginfo('template_url'); ?>/site/images/butcher-knives.svg" alt="">
            </div>
        </div>
    </section>
<?php endwhile; ?>

<?php get_footer(); ?>
