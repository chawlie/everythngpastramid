    </div><!-- Closing tag for page-wrapper -->

    <!-- Include analytics -->
    <?php get_template_part('analytics'); ?>

    <?php wp_footer(); ?>
</body>
</html>
