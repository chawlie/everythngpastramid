<?php
/**
 * Title: Taxonomies
 * Description: Custom taxonmies to be used by the theme.
 * Documentation: http://codex.wordpress.org/Taxonomies
 *
 * NOTE: For assistance creating custom taxonomies visit http://generatewp.com/
 */
?>
